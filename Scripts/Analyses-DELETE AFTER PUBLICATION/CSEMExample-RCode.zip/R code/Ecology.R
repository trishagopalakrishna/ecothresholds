# Title: An Improved Way of Studying Composites of Ecology using Structural Equation Modeling

#################
#### Read me ####
#################

# This R codes document contains 5 models, and the results are reported in Table 1 in the paper. 
# The 5 models are: 
# Model 1: Two-step approach;
# Model 2: H-O with unit weights; 
# Model 3: H-O with free weights;
# Model 4: One-step approach;
# Model 5: H-O with free weights + relaxed assumption. 

#renv for package version control
renv::restore()


#############################################
## Prepare the data: Get covariance matrix ##
#############################################

# Correlation matrix reported in Grace and Bollen (2008)
R=matrix(c(1,	0.0265,	0.1324,	-0.0465,	-0.0976,	0.2394,	-0.0073,
             0.0265,	1,	0.5767,	0.4604,	-0.3462,	0.2952,	-0.3369,
             0.1324,	0.5767,	1,	0.1844,	-0.3146,	0.3189,	-0.2553,
             -0.0465,	0.4604,	0.1844,	1,	-0.5934,	0.207,	-0.5785,
             -0.0976,	-0.3462,	-0.3146,	-0.5934	,1,	-0.4062,	0.6424,
             0.2394,	0.2952,	0.3189,	0.207,	-0.4062,	1,	-0.3423,
             -0.0073,	-0.3369,	-0.2553,	-0.5785,	0.6424,	-0.3423,	1
             
),7,7)

std_dev=c(0.7507, 1.1359, 0.4588, 0.8207, 0.3390, 0.3017, 0.1867)

# Obtain covariance matrix based on correlation matrix
VCV=cor2cov(R, std_dev)
dimnames(VCV)=list(c('ph',"mois","text","dist", "age","cover","colf"),c('ph',"mois","text","dist", "age","cover","colf"))


# Load library
library(lavaan)


################################
## Model 1: Two-step approach ##
################################

# Step 1: create composites
W=matrix(c(rep(1,3),rep(0,2),rep(0,3),rep(1,2)),ncol=2,byrow = F)
WW=as.matrix(Matrix::bdiag(t(W),diag(rep(1,2))))
sigma <- WW %*% VCV %*% t(WW)
rownames(sigma) <- c("soil","land","cover","colf")
colnames(sigma) <- c("soil","land","cover","colf")


# Step 2: run SEM
modelts <-'
# Specify common factor
Comp =~ cover
cover ~~ 0.009102*cover

Colo =~ colf
colf ~~ 0.003486*colf

# Specify structural model
Comp ~ soil + land
Colo ~ Comp + soil + land
soil ~~ land
'

outts <- sem(model = modelts, sample.cov = sigma, sample.nobs = 180)
summary(outts, standardized = T, fit.measures=T)
standardizedsolution(outts)



####################################
## Model 2: H-O with unit weights ##
####################################
modelho_u1<-'

# Specify emergent variables and label their loadings.
Soil =~ NA*mois + l11*ph + l12*mois + l13*text
l11 + l12 + l13 == 1

Land =~ NA*dist + l14*dist + l15*age
l14 + l15 == 1

# Label the variances of emergent variables.
Soil ~~ vsoil*Soil
Land ~~ vland*Land

# Specify the excrescent variables and label their loadings.
nu1 =~ 1*ph + (-1)*mois
nu2 =~ 1*text + (-1)*mois
nu3 =~ 1*age + (-1)*dist

# Label the variances of excrescent variables.
nu1 ~~ vnu1*nu1
nu2 ~~ vnu2*nu2
nu3 ~~ vnu3*nu3

# Specify common factors.
Comp =~ cover
cover ~~ 0.009102*cover

Colo =~ colf
colf ~~ 0.003486*colf

# Constrain the covariances of the excrescent variables
# with other variables in the structural model to zero.
# Label the covariances among excrescent variables within blocks.
nu1 ~~ 0*Soil + 0*Land + 0*Comp + 0*Colo + cov12*nu2 + 0*nu3
nu2 ~~ 0*Soil + 0*Land + 0*Comp + 0*Colo + 0*nu3
nu3 ~~ 0*Soil + 0*Land + 0*Comp + 0*Colo

# Fix the variances of the measurement errors to zero.
mois ~~ 0*mois
ph ~~ 0*ph
text ~~ 0*text
dist ~~ 0*dist
age ~~ 0*age

# Specify the structural model.
Comp ~ Soil + Land
Colo ~ Comp + Soil + Land

# Specify weights
wph := 1 / (l11 + l12 + l13)
wmois := 1 / (l11 + l12 + l13)
wtext := 1 / (l11 + l12 + l13)

wdist := 1 / (l14 + l15)
wage := 1 / (l14 + l15)

vph := ((l11)*(l11)*(vsoil)) + ((1)*(1)*(vnu1))
vmois := ((l12)*(l12)* (vsoil)) + ((-1)*(-1)*(vnu1)) + ((-1)*(-1)*(vnu2) + 2*(-1)*(-1)*(cov12))
vtext := ((l13)*(l13)*(vsoil)) + ((1)*(1)*(vnu2))

vdist := (l14)*(l14)*(vland) + (-1)*(-1)*(vnu3)
vage := (l15)*(l15)*(vland) + (1)*(1)*(vnu3)

wphs := wph * sqrt(vph / vsoil)
wmoiss := wmois * sqrt(vmois / vsoil)
wtexts := wtext * sqrt(vtext / vsoil)

wdists := wdist * sqrt(vdist / vland)
wages := wage * sqrt(vage / vland)
'

outho_u1=sem(model = modelho_u1, sample.cov = VCV, sample.nobs = 180)  
summary(outho_u1,standardized=T,fit.measures=T)  
standardizedsolution(outho_u1)




####################################
## Model 3: H-O with free weights ##
####################################

modelho_f1<-'

# Specify emergent variables and label their loadings.
Soil =~ NA*mois + l11*ph + + l12*mois + l13*text
l11 + l12 + l13 == 1

Land =~ NA*dist + l14*dist + l15*age
l14 + l15 == 1

# Label the variances of emergent variables.
Soil ~~ vsoil*Soil
Land ~~ vland*Land

# Specify the excrescent variables and label their loadings.
nu1 =~ ph + l22*mois
nu2 =~ text + l31*mois
nu3 =~ age + l41*dist

# Label the variances of excrescent variables.
nu1 ~~ vnu1*nu1
nu2 ~~ vnu2*nu2
nu3 ~~ vnu3*nu3

# Specify common factors.
Comp =~ cover
cover ~~ 0.009102*cover

Colo =~ colf
colf ~~ 0.003486*colf

# Constrain the covariances of the excrescent variables
# with other variables in the structural model to zero.
# Label the covariances among excrescent variables within blocks.
nu1 ~~ 0*Soil + 0*Land + 0*Comp + 0*Colo + cov12*nu2 + 0*nu3
nu2 ~~ 0*Soil + 0*Land + 0*Comp + 0*Colo + 0*nu3
nu3 ~~ 0*Soil + 0*Land + 0*Comp + 0*Colo

# Fix the variances of the measurement errors to zero.
mois ~~ 0*mois
ph ~~ 0*ph
text ~~ 0*text
dist ~~ 0*dist
age ~~ 0*age

# Specify the structural model.
Comp ~ Soil + Land
Colo ~ Comp + Soil + Land

# Specify weights
wph := (l22) / (-l12 + (l11)*(l22) + (l13)*(l31))
wmois := -((1) / ((-l12) + (l11)*(l22) + (l13)*(l31)))
wtext := (l31) / ((-l12) + (l11)*(l22) + (l13)*(l31))

wdist := (1) / ((l14) - (l15)*(l41))
wage := -((l41) / (l14 - (l15)*(l41)))

vph := ((l11)*(l11)*(vsoil)) + ((1)*(1)*(vnu1))
vmois := ((l12)*(l12)* (vsoil)) + ((l22)*(l22)*(vnu1)) + ((l31)*(l31)*(vnu2) + 2*(l22)*(l31)*(cov12))
vtext := ((l13)*(l13)*(vsoil)) + ((1)*(1)*(vnu2))

vdist := (l14)*(l14)*(vland) + (l41)*(l41)*(vnu3)
vage := (l15)*(l15)*(vland) + (1)*(1)*(vnu3)

wphs := wph * sqrt(vph / vsoil)
wmoiss := wmois * sqrt(vmois / vsoil)
wtexts := wtext * sqrt(vtext / vsoil)

wdists := wdist * sqrt(vdist / vland)
wages := wage * sqrt(vage / vland)
'

outho_f1=sem(model = modelho_f1,sample.cov = VCV,sample.nobs = 180)  
summary(outho_f1,standardized=T,fit.measures=T) 
standardizedsolution(outho_f1)



################################
## Model 4: One-step approach ##
################################

modelos='

# Specify composites.
Soil ~ 1*ph + mois + text
Soil =~ 0

Land ~ 1*dist + age
Land =~ 0

# Specify common factors.
Comp =~ cover
cover ~~ 0.009102*cover

Colo =~ colf
colf ~~ 0.003486*colf

# Specify measurement error of composites to zero.
Soil ~~ 0*Soil
Land ~~ 0*Land

# Specify the covariance among observed variables.
ph ~~ mois + text + dist + age
mois ~~ text + dist + age
text ~~ dist + age
dist ~~ age

# Specify the structural model.
Comp ~ Soil + Land
Colo ~ Comp + Soil + Land
'

outos=sem(model = modelos, sample.cov = VCV, sample.nobs = 180)  
summary(outos, standardized=T, fit.measures=T)  
standardizedsolution(outos)



#########################################################
## Model 5: H-O with free weights + relaxed assumption ##
#########################################################

modelho_a1<-'

# Specify emergent variables and label their loadings.
Soil =~ NA*mois + l11*ph + + l12*mois + l13*text
l11 + l12 + l13 == 1

Land =~ NA*dist + l14*dist + l15*age
l14 + l15 == 1

# Label the variances of emergent variables.
Soil ~~ vsoil*Soil
Land ~~ vland*Land

# Specify the excrescent variables and label their loadings.
nu1 =~ ph + l22*mois
nu2 =~ text + l31*mois
nu3 =~ age + l41*dist

# Label the variances of excrescent variables.
nu1 ~~ vnu1*nu1
nu2 ~~ vnu2*nu2
nu3 ~~ vnu3*nu3

# Specify common factors.
Comp =~ cover
cover ~~ 0.009102*cover

Colo =~ colf
colf ~~ 0.003486*colf

# Constrain the covariances of the excrescent variables
# with other variables in the structural model to zero.
# Allow and label the covariances among excrescent variables across blocks.
nu1 ~~ 0*Soil + Land + 0*Comp + 0*Colo + cov12*nu2 + cov13*nu3
nu2 ~~ 0*Soil + Land + 0*Comp + 0*Colo + cov23*nu3
nu3 ~~ Soil + 0*Land + 0*Comp + 0*Colo

# Fix the variances of the measurement errors to zero.
mois ~~ 0*mois
ph ~~ 0*ph
text ~~ 0*text
dist ~~ 0*dist
age ~~ 0*age

# Specify the structural model.
Comp ~ Soil + Land
Colo ~ Comp + Soil + Land

# Specify weights
wph := (l22) / (-l12 + (l11)*(l22) + (l13)*(l31))
wmois := -((1) / ((-l12) + (l11)*(l22) + (l13)*(l31)))
wtext := (l31) / ((-l12) + (l11)*(l22) + (l13)*(l31))

wdist := (1) / ((l14) - (l15)*(l41))
wage := -((l41) / (l14 - (l15)*(l41)))

vph := ((l11)*(l11)*(vsoil)) + ((1)*(1)*(vnu1))
vmois := ((l12)*(l12)* (vsoil)) + ((l22)*(l22)*(vnu1)) + ((l31)*(l31)*(vnu2) + 2*(l22)*(l31)*(cov12))
vtext := ((l13)*(l13)*(vsoil)) + ((1)*(1)*(vnu2))

vdist := (l14)*(l14)*(vland) + (l41)*(l41)*(vnu3)
vage := (l15)*(l15)*(vland) + (1)*(1)*(vnu3)

wphs := wph * sqrt(vph / vsoil)
wmoiss := wmois * sqrt(vmois / vsoil)
wtexts := wtext * sqrt(vtext / vsoil)

wdists := wdist * sqrt(vdist / vland)
wages := wage * sqrt(vage / vland)
'

outho_a1=sem(model = modelho_a1, sample.cov = VCV, sample.nobs = 180)  
summary(outho_a1, standardized=T, fit.measures=T) 
standardizedsolution(outho_a1)